#include <stdio.h>
//짝수 홀수 판별
int main(void){
    int a=scanf("%d", &a);
    if(a%2==0)printf("짝수입니댜\n");
    else printf("홀수 입니다 \n");
}