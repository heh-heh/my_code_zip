#include <stdio.h>
#include <stdlib.h>


#define tsst(a) if(a) 10; else 0;
int main()
{
    int b=test(1);
    printf("%d",b);
    return 0;
}
