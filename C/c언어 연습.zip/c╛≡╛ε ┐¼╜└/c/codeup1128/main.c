#include<stdio.h>
int main()
{
    unsigned long a=0;
    int b=0;
    scanf("%d",&b);
    a=b*123456789;
    printf("%llu", b*123456789ULL);

}
