#include <stdio.h>
int main(void){
    float px=88, px2=33;
    float ee;

    printf("%f",px/px2*1.8);
}
