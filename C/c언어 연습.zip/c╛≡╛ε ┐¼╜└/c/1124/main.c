#include<stdio.h>
int main()
{
  int c,h;
  scanf("C%dH%d",&c,&h);

  printf("%d",(c*12)+h);
}
