#include<stdio.h>
int main()
{
    int a=0;

    scanf("%d", &a);
    printf("%o %X",a,a);
}
