#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    printf("%d",colck());
    return 0;
}
