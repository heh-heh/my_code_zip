#include<stdio.h>
int main()
{
    int c=0;
    double cc=0;

    scanf("%d",&c);

    cc=(c*1.8)+32;

    printf("%.3f", cc);

}
