#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=0;
    printf("%s",type(a));
    return 0;
}
