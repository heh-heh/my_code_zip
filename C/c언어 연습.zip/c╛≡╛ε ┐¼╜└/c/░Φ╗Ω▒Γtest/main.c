#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double
    double v[3]=cos(0*3.141592/180)*300- cos((90-0)*3.141592/180) * 0;
    printf("%f", i);
    return 0;
}
