#include<stdio.h>
int main()
{
   int i=0;
   while(i<20)
   {
       printf("hello");
       i++;
   }

   printf(" ");
   i=0;
   while(i<30)
   {
       printf("world");
       i++;
   }
}
