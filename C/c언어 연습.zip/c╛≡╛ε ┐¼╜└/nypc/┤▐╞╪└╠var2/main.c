#include <stdio.h>
#include <stdlib.h>

int main()
{
    int map[5][5]={0};
    int ii,jj,C=0;
    for(int i=0; i<5; i++)map[0][i]=++C;

    for(int i=0; i<5-1; i++){
        for(ii=4)
    }
}
