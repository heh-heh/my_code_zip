
<form class="col-6" name="loginForm" method="POST" action="<?=$PHP_SELF?>?cmd=homelogininit.php?homelogin">
    <div class="col">
        <input type="text" name="id" class="form-control" placeholder="ID">
    </div>
    <div class="col">
        <input type="password" name="pass" class="form-control" placeholder="PW">
    </div>
    <div class="col">
        <button type="submit" class="btn btn-primary form-control">
            <span class="material-icons">login</span> 로그인
        </button>
        
    </div>
    
</form>
    
