<?
	// inc/homeconfig.inc.php

	$ssession_id = "highshcool_session_id";
	$ssession_level = "highschool_session_level";
	$ssession_name = "highschool_session_name";
	$adminLevel >= 4;
?>

